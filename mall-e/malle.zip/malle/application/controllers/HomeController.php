<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller
{
	
	public function index()
	{	
		$data['title'] = 'Mall-E';
		$this->load->view('home_view',$data);
	}
}