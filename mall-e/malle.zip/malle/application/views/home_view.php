<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

	<title><?= $title ?></title>

	<link href="<?= base_url('assets/images/logo/malle.png') ?>" rel="icon" type="image">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/malle_style.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/fontawesome/css/all.css') ?>">

</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light fixed-top bg-white	shadow-sm">
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		</button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="#">
	        	<i class="fas fa-bars malle-bars"></i>
	        </a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="#">
	        	<img class="malle-logo" src="<?= base_url('assets/images/logo/rec.png') ?>" >
	        </a>
	      </li>
	      <li class="nav-item">
	      	<select class="malle-country mt-2">
	      		<option>Singapore</option>
	      		<option>India</option>
	      		<option>Philippines</option>
	      	</select>
	      </li>
	    </ul>
	    <ul class="navbar-nav my-2 my-lg-0">
	    	<li class="nav-item">
	    		Merchant
	      		<button class="btn-orange my-2 my-sm-0 ml-2 mr-3" type="submit">Open Free Account</button>
	    	</li>
	    	<li class="nav-item">
	    		Shoppers
	      		<button class="btn-red my-2 my-sm-0 ml-2" type="submit">Quick Register</button>
	    	</li>
	    </ul>
	  </div>
	</nav>
	<div class="container-fluid">
		<div class="row malle-body" id="malle-body">
			<div class="col-md-12">
				<img class="malle-logo2" id="intro" src="<?= base_url('assets/images/logo/rec.png') ?>">
			</div>
			<div class="col-md-12" id="intro2">
				<h2>Are you going to a mall?</h2>
				<p>Looking for Discounts, Coupon, Sales</p>
			</div>
		</div>
		<div class="row malle-features-container">
			<div class="row malle-features">
				<div class="col-md-4 mt-5" id="malls">
					<div class="card card1" style="width: 18rem;">
					  	<img class="card-img-top malle-pic" src="<?= base_url('assets/images/src/malls.jpg') ?>" alt="Merchants">
					 	<div class="card-body malle-card">
					    	<h5 class="card-title">Malls</h5>
					    	<p class="card-text">Nearby a Mall or going to a Mall find various malls around you.</p>
					  </div>
					  <div class="card-footer footer1">
					  	<a href="#" ><button class="btn-gray">View (10 Malls)</button></a>
					  </div>
					</div>
				</div>
				<div class="col-md-4 mt-5" id="merchant">
					<div class="card card2" style="width: 18rem;">
					  	<img class="card-img-top malle-pic" src="<?= base_url('assets/images/src/merchant.jpg') ?>" alt="Merchants">
					 	<div class="card-body malle-card">
					    	<h5 class="card-title">Merchants</h5>
					    	<p class="card-text">Looking for a specific Merchant or a Brand ..Look no further as we have your favorite merchants onboard.</p>
					    </div>
					  <div class="card-footer footer2">
					  	<a href="#"><button class="btn-gray">View 15 Merchants</button></a>
					  </div>
					</div>
				</div>
				<div class="col-md-4 mt-5" id="deals">
					<div class="card card3" style="width: 18rem;">
					  	<img class="card-img-top malle-pic" src="<?= base_url('assets/images/src/deals.jpg') ?>" alt="Merchants">
					 	<div class="card-body malle-card">
					    	<h5 class="card-title">Deals</h5>
					    	<p class="card-text">Awesome Deals, Massive Sales, whether they are Coupons or Discounts.</p>
					    	 </div>
					  <div class="card-footer footer3">
					  	<a href="#"><button class="btn-gray">View 75 Deals</button></a>
					  </div>
					</div>
				</div>
			</div>
		</div>
		<div class="row latest-deals-container">
			<div class="row latest-deals">
				<div class="col-md-12"><h3>Latest Deals</h3></div>
				<div class="col-md-3 mt-3">
					<div class="card latest-deals-card" style="width: 18rem;">
					  <img class="card-img-top card-img latest-deals-img" src="<?= base_url('assets/images/src/au.jpg') ?>" alt="Card image cap">
					  <div class="card-img-overlay"><p class="img-overlay">Buy 1 Get 1 for <strong>P90</strong></p></div>
					  <div class="card-body">
					    <div class="row">
					    	<div class="col-md-3">
					    		<img class="latest-deals-logo" src="<?= base_url("assets/images/src/aulogo.jpg") ?>">
					    	</div>
					    	<div class="col-md-9">
					    		<h5>Auntie Anne's</h5>
					    		<p>Yohgurt Popping Lemonade - <strong>18</strong> Branches</p>
					    	</div>
					    </div>
					  </div>
					</div>
				</div>
				<div class="col-md-3 mt-3">
					<div class="card latest-deals-card" style="width: 18rem;">
					  <img class="card-img-top card-img latest-deals-img" src="<?= base_url('assets/images/src/gn.jpg') ?>" alt="Card image cap">
					  <div class="card-img-overlay"><p class="img-overlay">Buy 1 Get 1 for <strong>P130</strong></p></div>
					  <div class="card-body">
					    <div class="row">
					    	<div class="col-md-3">
					    		<img class="latest-deals-logo" src="<?= base_url("assets/images/src/gnl.png") ?>">
					    	</div>
					    	<div class="col-md-9">
					    		<h5>Gong Cha</h5>
					    		<p>Gong Cha Milk Brown Sugar - <strong>61</strong> Branches</p>
					    	</div>
					    </div>
					  </div>
					</div>
				</div>
				<div class="col-md-3 mt-3">
					<div class="card latest-deals-card" style="width: 18rem;">
					  <img class="card-img-top card-img latest-deals-img" src="<?= base_url('assets/images/src/kn.png') ?>" alt="Card image cap">
					  <div class="card-img-overlay"><p class="img-overlay">Buy 1 Get 1 for <strong>P140</strong></p></div>
					  <div class="card-body">
					    <div class="row">
					    	<div class="col-md-3">
					    		<img class="latest-deals-logo" src="<?= base_url("assets/images/src/knl.png") ?>">
					    	</div>
					    	<div class="col-md-9">
					    		<h5>Kenny Roger's Roasters</h5>
					    		<p>Kani & Mango Salad - <strong>33</strong> Branches</p>
					    	</div>
					    </div>
					  </div>
					</div>
				</div>
				<div class="col-md-3 mt-3">
					<div class="card latest-deals-card" style="width: 18rem;">
					  <img class="card-img-top card-img latest-deals-img" src="<?= base_url('assets/images/src/cc.jpg') ?>" alt="Card image cap">
					  <div class="card-img-overlay"><p class="img-overlay">Buy 1 Get 1 for <strong>P90</strong></p></div>
					  <div class="card-body">
					    <div class="row">
					    	<div class="col-md-3">
					    		<img class="latest-deals-logo" src="<?= base_url("assets/images/src/ccl.png") ?>">
					    	</div>
					    	<div class="col-md-9">
					    		<h5>Cara Mia Cakes & Gelato</h5>
					    		<p>Rocky Road Gelato - <strong>19</strong> Branches</p>
					    	</div>
					    </div>
					  </div>
					</div>
				</div>
			</div>
		</div>
		<div class="row app-download">
			<div class="col-md-6">
				<img class="phone pull-right" src="<?= base_url('assets/images/src/IPhone_X.png') ?>">
			</div>
			<div class="col-md-6 pl-4 phone-s">
				<h4 class="pt-5 mt-4">Have you got the app?</h4>
				<p>Get yours now - available on the iOS and Android app stores!</p>
				<a href="#"><img class="dlink" src="<?= base_url('assets/images/src/ios.png') ?>"></a>
				<a href="#"><img class="dlink" src="<?= base_url('assets/images/src/andoird.png') ?>"></a>
				<br>
				<a href="#"><i class="fab fa-facebook-f  social1 mt-3"></i></a>
				<a href="#"><i class="fab fa-twitter social2"></i></a>
				<a href="#"><i class="fab fa-instagram social3"></i></a>

			</div>
		</div>

		<footer>
			<div class="row malle-footer">
				<div class="col-md-3 malle-footer-content">
					<div class="cont"></div>
				</div>
				<div class="col-md-3 malle-footer-content">
					<div class="cont"></div>
				</div>
				<div class="col-md-3 malle-footer-content">
					<div class="content">
						Social Media
						<br>
						<a href="#"><i class="fab fa-facebook-f mt-4"></i></a>
						<a href="#"><i class="fab fa-twitter"></i></a>
						<a href="#"><i class="fab fa-instagram"></i></a>
					</div>
				</div>
				<div class="col-md-3 malle-footer-content">
					<div class="content2">
						Mobile App
						<br>
						<a href="#"><img class="dlink2 mt-3" src="<?= base_url('assets/images/src/ios.png') ?>"></a>
						<a href="#"><img class="dlink2 mt-2" src="<?= base_url('assets/images/src/andoird.png') ?>"></a>
					</div>
				</div>
			</div>

			<script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TweenMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TimelineMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/plugins/ScrollToPlugin.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/malle.js') ?>"></script>
		</footer>
	</div>
</body>
</html>