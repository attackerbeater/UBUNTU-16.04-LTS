<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

	<title><?= $title ?></title>

	<link href="<?= base_url('assets/images/logo/malle.png') ?>" rel="icon" type="image">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/malle_style.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/fontawesome/css/all.css') ?>">

</head>
<body class="admin-body">
	
	<div class="container">
		<div class="card card-container">
			<img class="img-card-admin" src="<?= base_url('assets/images/logo/malle.png') ?>">
			<form class="form-admin-login">
				<div class="form-group">
					<input type="text" name="email" placeholder="Email Address" class="form-control" required>
				</div>
				<div class="form-group">
					<input type="password" name="password" placeholder="Password" class="form-control" required>
				</div>
				<div class="form-group">
					<button type="submit" class="btn btn-block btn-sign-in">Sign in</button>
				</div>
			</form>
		</div>

		<footer>
			

			<script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TweenMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TimelineMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/plugins/ScrollToPlugin.min.js') ?>"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>		
			<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/malle.js') ?>"></script>
		</footer>
	</div>
</body>
</html>