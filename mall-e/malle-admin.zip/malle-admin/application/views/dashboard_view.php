<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

	<title><?= $title ?></title>

	<link href="<?= base_url('assets/images/logo/malle.png') ?>" rel="icon" type="image">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/malle_style.css') ?>">
	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/fontawesome/css/all.css') ?>">

</head>
<body class="dashboard-body">
	<nav class="navbar navbar-light bg-malle">
		<div class="container">
			<a class="navbar-brand text-light" href="#">
	    		<img src="<?= base_url('assets/images/logo/rec.png')?>" width="110" height="50" class="d-inline-block align-top" alt="">
	    		| Admin Dashboard
	  		</a>
	  		<button class="my-2 btn btn-danger bg-red">Logout</button>
		</div>
	</nav>	
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2 mt-4">
				<div class="sidebar">
					<div class="container">
						<div class="row">
							<h5>Hi ! <span class="text-info">Charlton</span></h5>
							<br>
							<div class="text-email">acharltonmendes@gmail.com</div>
						</div>
						<hr>
					</div>
					<ul class="list-group list-group-flush">
					  <li class="list-group-item"><a class="malle-link" href="<?= base_url('home') ?>">Manage Malls</a></li>
					  <li class="list-group-item"><a class="malle-link" href="<?= base_url('merchant') ?>">Manage Merchants</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Deals</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Shops/Outlets</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Company</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Country</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Masters</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Category</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Sub Category</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Inquiry</a></li>
					  <li class="list-group-item"><a class="malle-link" href="#">Manage Shoppers</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-10">
				<div class="row">
					<div class="col-md-10">
						<div class="card card-malle">
							<div class="card-header-malle">Manage Malls</div>
							<div class="card-body">
								<form class="form-inline">
									<div class="form-group col-md-7">
										<input type="text" name="mallname" placeholder="Mall Name" class="form-control col-md-12">
									</div>
									<div class="form-group">
										<div class="dropdown">
											<button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">City</button>
											    <div class="dropdown-menu">
											      <a class="dropdown-item" href="#">Singapore City</a>
											      <a class="dropdown-item" href="#">Ernakulam</a>
											      <a class="dropdown-item" href="#">Thrissur</a>
											      <a class="dropdown-item" href="#">Mumbai</a>
											      <a class="dropdown-item" href="#">Navi Mumbai</a>
											      <a class="dropdown-item" href="#">Kochi</a>
											      <a class="dropdown-item" href="#">Manila</a>
											      <a class="dropdown-item" href="#">Tagbilaran</a>
											    </div>
										</div>
									</div>
									<div class="col-md-1">
										<button type="submit" class="btn btn-primary">Update</button>
									</div>
								</form>
								<hr>
								<div class="row">
									<div class="col-md-11">
										<table class="table table-striped malle-table">
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
											<tr>
												<td>112 Katong Mall, Singapore City</td>
												<td class="text-right"><a href="#"><span class="text-success">Edit</span></a> | <a href="#" data-mid="26" class="removeMall"><span class="text-danger" >Delete</span></a></td>
											</tr>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<footer>
			

			<script type="text/javascript" src="<?= base_url('assets/js/jquery.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TweenMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/TimelineMax.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/greensock-js/src/minified/plugins/ScrollToPlugin.min.js') ?>"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.min.js"></script>
			<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/debug.addIndicators.min.js"></script>		
			<script type="text/javascript" src="<?= base_url('assets/js/popper.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js') ?>"></script>
			<script type="text/javascript" src="<?= base_url('assets/js/malle.js') ?>"></script>
		</footer>
	</div>
</body>
</html>