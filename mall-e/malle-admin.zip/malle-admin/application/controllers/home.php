<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller
{
	
	public function index()
	{	
		$data['title'] = 'Mall-E - Dashboard';
		$this->load->view('dashboard_view',$data);
	}

}