<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//get

/* -------- GENERAL --------- */
Route::get('countries','API\CountryController@index');
Route::get('show_merchant_type/{id}','API\MerchantController@view_choosen_mall_type');
Route::get('show_merchant_type_plus/{id}','API\MerchantController@view_choosen_mall_type_plus'); 
Route::get('merchant_inMall','API\MallController@location_merchant_perMall'); 
Route::get('all_merchant','API\MerchantController@allMerchant'); 
Route::get('subCategories','API\SubCategoryController@index');
Route::get('subCategoriesNoMall','API\SubCategoryController@sc_noMall');

Route::get('deals','API\DealController@index');
Route::get('events','API\EventController@index');
Route::get('category/{id}','API\DealController@getDeals'); 
Route::get('MallsperCountry','API\CountryController@MallsperCountry');
//Route::get('mall_type','API\MallController@view_mall_type');
Route::get('show_mt_mall/{id}','API\MallController@view_choosen_mall_type');

/* -------- MALL E --------- */

Route::get('malls','API\MallController@index');
Route::get('mall/{id}','API\MallController@search');

Route::get('merchants','API\MerchantController@index');
Route::get('merchant/{id}','API\MerchantController@search');
Route::get('merchant_type','API\MerchantController@view_merchant_type'); 

Route::get('transaction_deals','API\DealController@GetTransactionDeals');
Route::get('promo_category','API\PromotionTagController@index');
Route::get('promo_outlets','API\PromotionTagController@promo_outlets');
Route::get('parkings','API\MallController@getParking');
Route::get('offers','API\MallController@getOffers');
Route::get('promo_master_category','API\PromotionTagController@promo_master_category');
Route::get('promo_master','API\PromotionTagController@promo_master');


/* -------- MALL E PLUS --------- */

Route::get('merchant_type_plus','API\MerchantController@merchant_type_plus');  
Route::get('view_merchant_plus','API\MerchantController@view_merchant_plus'); 
Route::get('mall_type_count','API\MallController@view_mall_type_count');
Route::get('parkings_plus','API\MallController@getParkingPlus');
Route::get('offers_plus','API\MallController@getOffersPlus');
Route::get('promo_outlets_plus','API\PromotionTagController@promo_outlets_plus');
Route::get('promo_category_plus','API\PromotionTagController@tags_plus');


//post
 
Route::post('savePreRedeem','API\DealController@StorePreRedeem'); 
Route::post('createMerchant','API\MerchantController@store');
Route::post('validate-email','API\ShopperController@verify_email');
Route::post('validate-otp','API\ShopperController@verify_otp');
Route::post('saveShopper','API\ShopperController@store');



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
