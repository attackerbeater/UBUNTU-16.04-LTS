<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TownMaster extends Model
{
    
    protected $guarded = [];

    protected $table = 'town_master';


	public function user()
	 {
	 	return $this->belongsTo(User::class,'user_id');
	 }
}
