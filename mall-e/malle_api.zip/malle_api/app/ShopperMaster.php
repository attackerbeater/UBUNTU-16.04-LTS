<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShopperMaster extends Model
{
	const UPDATED_AT = null;
	const CREATED_AT = null;
	protected $primaryKey = 'Shopper_id';
	
    protected $guarded = [];
    

    protected $table = 'shoppers_master';

    public function images()
	    {
	    	return $this->hasMany(MerchantImage::class, 'merchant_id', 'merchant_id');
	    }
	public function mall()
	{
	    	return $this->hasMany(MallMaster::class, 'mall_id', 'mall_id');
	    }
	public function merchant_location()
	{
	    	return $this->hasMany(MerchantMall::class, 'merchant_id', 'merchant_id');
	    }
}
