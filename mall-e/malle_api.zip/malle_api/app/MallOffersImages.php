<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class MallOffersImages extends Model
{
    protected $guarded = [];

    protected $table = 'mall_offers_images';

}
