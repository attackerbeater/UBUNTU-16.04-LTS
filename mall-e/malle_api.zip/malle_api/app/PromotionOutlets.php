<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PromotionOutlets extends Model
{
    protected $guarded = [];

    protected $table = 'promotions_outlets';

     public function tag_name()
	{
			return $this->hasMany(PromotionTag::class, 'po_id', 'po_id')
	    			->join('tags_master','tags_master.tag_id','promotions_tags.tag_id')
	    			->select('tags_master.tag_name as tag_name')
	    			->where('promotions_tags.primary_tag', '=', 'Y');

	    			
	}  
}
