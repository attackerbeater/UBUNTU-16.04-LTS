<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventImages extends Model
{
    protected $guarded = [];

    protected $table = 'event_image';
}
