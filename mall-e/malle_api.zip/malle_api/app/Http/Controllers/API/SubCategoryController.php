<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\DealMaster;
use App\SubCategoryNoMallMaster;
use App\Http\Resources\DealResource;
use App\SubCategoryMaster;
use App\Http\Resources\SubCategoryResource;

class SubCategoryController extends Controller
{
    public function index(){

    	$sub_category = SubCategoryMaster::all();
		//var_export($sub_category);
		//exit();
    	return SubCategoryResource::collection($sub_category);
    }

    public function sc_noMall(){

    	$sub_category = SubCategoryNoMallMaster::all();
		//var_export($sub_category);
		//exit();
    	return SubCategoryResource::collection($sub_category);
    }


	
	
}
