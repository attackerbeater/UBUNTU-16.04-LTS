<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\DealMaster;
use App\Http\Resources\DealResource;
use App\TransactionMaster;
use App\Http\Resources\TransactionResource;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

class DealController extends Controller
{
    public function index(){
    	

    	$deals = DealMaster::join('deals_images','deals_images.di_id','deal_master.di_id') 
    						->join('deals_main','deals_main.dm_id','deal_master.dm_id') 
    						->select('deal_master.*', 'deals_images.deal_image as deal_image', 'deals_main.deal_main_name as deal_main_name')  
    	                    ->where('deal_master.deal_status', 'L')
    	                    ->where('deals_images.img_count', '1')->get();
 		
 		return DealResource::collection($deals); 

    }

    public function StorePreRedeem(Request $request)
    {
        
	 

		$shopper_id = $request->input('shopper_id');
		$dm_id = $request->input('dm_id');
		//$Payment_by =  $request['Payment_by'];
		$deal_by =  $request->input('deal_by');
		$deal_at =  $request->input('deal_at');
		$qty =  $request->input('qty');
		$deal_amount =  $request->input('deal_amount');
		$total_amount =  $request->input('total_amount');
		$deal_type =  $request->input('deal_type');
		//$transact_date =  $request['transact_date'];
		//$transact_time =  $request['transact_time'];
		//$Points =  $request['Points'];
 
		 $TransactionMaster = new TransactionMaster;
         $TransactionMaster->dm_id = $dm_id;  
         $TransactionMaster->transact_date =  date("d/m/Y"); 
         $TransactionMaster->shopper_id = $shopper_id; 
         $TransactionMaster->deal_by = $deal_by; 
         $TransactionMaster->deal_at = $deal_at; 
         $TransactionMaster->qty = $qty; 
         $TransactionMaster->deal_amount = $deal_amount; 
         $TransactionMaster->total_amount = $total_amount; 
         $TransactionMaster->deal_type = $deal_type; 
         $TransactionMaster->transact_time = date("h:i a");  
		
		if($TransactionMaster->save()){
			$request['success'] = true;
		}
		else{
			$request['success'] = false;
		}
		
		return $request;

    }

    public function GetTransactionDeals(){
 

    	$trans = TransactionMaster::join('deal_master','transactions_master.dm_id','deal_master.dm_id')
								->join('merchant_master','transactions_master.deal_by','merchant_master.merchant_id') 
								->join('mall_master', 'transactions_master.deal_at', 'mall_master.mall_id')
								->join('city_master', 'city_master.city_id', 'mall_master.city_id')
								->get();

		return TransactionResource::collection($trans);

	}
//	public function getDeals(){
//
//    	$deals = DealMaster::where('sub_category_id', $category)
//						  ->where('deal_status', 'L')
//                          ->get();
//
//    	return DealResource::collection($deals);
//    }
//	
//	public function viewDealsperCategory(){
//		$sub_category = SubCategoryMaster::get();
//
//    	return DealResource::collection($sub_category);
//	}
	
	
}
