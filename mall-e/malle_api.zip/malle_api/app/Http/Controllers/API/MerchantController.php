<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\MerchantMaster;
use App\MerchantType;
use App\InquiryMaster;
use App\Http\Resources\MerchantResource;
use App\Http\Resources\MerchantTypeResource;
use Mail;
use App\Mail\NewMerchant;
use App\Mail\NewMerchantAdmin;
use DB;

class MerchantController extends Controller
{
    public function index(){
    	
    	$merchants = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', 'merchant_master.mt_id')
								->select('merchant_master.main_image', 'mall_master.*', 'merchant_locations.*','merchant_type.*','merchant_master.*')
								->where('merchant_master.merchant_active', 'Y')
								->where('mall_master.mt_id', '=', '1') 
								->get();

    	return MerchantResource::collection($merchants);
								//return $merchants;
    }

    public function allMerchant(){

    		$merchants = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', 'merchant_master.mt_id')
								->select('merchant_master.main_image', 'mall_master.*', 'merchant_locations.*','merchant_type.*','merchant_master.*' )
								->where('merchant_master.merchant_active', 'Y') 
								->groupBy('merchant_locations.merchant_id')
								->distinct()->get();

    	return MerchantResource::collection($merchants);
								 
    }
	
	public function search($id){
		
		
    	$merchants = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id')
								->where('merchant_master.merchant_id', $id)
								->get();

    	return MerchantResource::collection($merchants);
    }
	
	public function store(Request $request)
    {
        
		
		
		$name = $request['Contact_person'];
		$mobile =  $request['Contact_number'];
		$country =  $request['Country'];
		$email =  $request['Email_id'];
		$merchant_name =  $request['Outlet_name'];
		
		$inquiry = array();
		$inquiry['merchant_name'] = $merchant_name;
		$inquiry['name'] = $name;
		$inquiry['number'] = $mobile;
		$inquiry['country'] = $country;
		$inquiry['sender'] = $email;
		
		Mail::to($email)->send(new NewMerchant($inquiry));
		$email = 'admin@mall-e.net';
		Mail::to($email)->send(new NewMerchantAdmin($inquiry));
		
		if(InquiryMaster::create($request->all())){
			$request['success'] = true;
		}
		else{
			$request['success'] = false;
		}
		
		return $request;

    }

      public function view_merchant_type(){
  

    	$merch_type = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', '=', 'merchant_master.mt_id')
								->join('country_master', 'country_master.country_id', '=', 'merchant_master.country_id')
								->select('merchant_master.mt_id as mt_id', 'merchant_type.type as type', DB::raw("count(merchant_master.mt_id) as count"), 'merchant_type.image as image', 'country_master.country_name as country_name', 'merchant_master.country_id as country_id')
								->groupBy('merchant_type.type') 
								->where('merchant_master.merchant_active', '=', 'Y')
								->where('mall_master.mt_id', '=', '1')->get(); 

    	return MerchantTypeResource::collection($merch_type);
    }

     public function merchant_type_plus(){


     		$merch_type = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', '=', 'merchant_master.mt_id')
								->join('country_master', 'country_master.country_id', '=', 'merchant_master.country_id')
								->select('merchant_master.mt_id as mt_id', 'merchant_type.type as type', DB::raw("count(merchant_master.mt_id) as count"), 'merchant_type.image as image', 'country_master.country_name as country_name', 'merchant_master.country_id as country_id')
								->groupBy('merchant_type.type') 
								->where('merchant_master.merchant_active', '=', 'Y')
								->where('mall_master.mt_id', '!=', '1')->get(); 

    	return MerchantTypeResource::collection($merch_type);
    }




	 public function view_choosen_mall_type($id){

    	//$mt_choosen = MerchantMaster::where('mt_id', $id)->get();
		
    	//return MerchantResource::collection($mt_choosen); 

		$mt_choosen = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', 'merchant_master.mt_id')
								->select('merchant_master.main_image', 'mall_master.*', 'merchant_locations.*','merchant_type.*','merchant_master.*' )
								->where('merchant_master.mt_id', $id)
								->where('merchant_master.merchant_active', 'Y')
								->where('mall_master.mt_id', '=', '1') 
								->get();

    	return MerchantResource::collection($mt_choosen);

    	 
    }

     public function view_choosen_mall_type_plus($id){

    	//$mt_choosen = MerchantMaster::where('mt_id', $id)->get();
		
    	//return MerchantResource::collection($mt_choosen); 

		$mt_choosen = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', 'merchant_master.mt_id')
								->select('merchant_master.main_image', 'mall_master.*', 'merchant_locations.*','merchant_type.*','merchant_master.*' )
								->where('merchant_master.mt_id', $id)
								->where('merchant_master.merchant_active', 'Y')
								->where('mall_master.mt_id', '!=', '1') 
								->get();

    	return MerchantResource::collection($mt_choosen);

    	 
    }

    public function view_merchant_plus(){ 

    	$no_mall = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->where('mall_master.mt_id', '!=', '1')->get(); 

    	return MerchantResource::collection($no_mall); 

    	 
    }



    
	
	 
}
