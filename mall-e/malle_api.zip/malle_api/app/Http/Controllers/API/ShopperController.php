<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ShopperMaster;
use App\InquiryMaster;
use App\Http\Resources\MerchantResource;
use Mail;
use App\Mail\EmailOtp;
use App\Mail\ShopperSuccess;

class ShopperController extends Controller
{
    public function index(){

    	$merchants = MerchantMaster::join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id')
								->where('merchant_master.merchant_active', 'Y')->get();

    	return MerchantResource::collection($merchants);
    }
	
	public function verify_email(Request $request){
		$result = array();
		$email = $request['Email_id'];
    	$result = ShopperMaster::where('shoppers_master.Email_id', $email)->get();
    	//var_export($result);
		//echo $result[0]['is_validated'];
		if(count($result) >0 && $result[0]['is_validated'] == 1){
			$result['success'] = false;
			$result['message'] = 'Email is already been taken';
			
		}else if($result[0]['is_validated'] == 0){
			$request['Otp'] =  $this->generateRandomString();
			//update otp in table
			
			$shoppers = ShopperMaster::find($result[0]['Shopper_id']);
			
			$shoppers->Otp = $request['Otp'];
			
			if($shoppers->save()){
				//send email
				$inquiry = array();
				$inquiry['otp'] = $shoppers->Otp;
				
				Mail::to($email)->send(new EmailOtp($inquiry));
				$result = ShopperMaster::where('shoppers_master.Email_id', $email)->get();
				
				$result['Email_id'] = $email;
				$result['success'] = true;
				$result['message'] = 'OTP was sent into your email';
			}
			else{
				$result['success'] = false;
			}
		}
    	else{
			$request['Otp'] =  $this->generateRandomString();
			//insert into table first the email
			if(ShopperMaster::create($request->all())){
				//send email
				$inquiry = array();
				$inquiry['otp'] = $request['Otp'];
				
				Mail::to($email)->send(new EmailOtp($inquiry));
				$result = ShopperMaster::where('shoppers_master.Email_id', $email)->get();
				
				$result['Email_id'] = $email;
				$result['success'] = true;
				$result['message'] = 'OTP was sent into your email';
			}
			else{
				$result['success'] = false;
			}
		}
    	
    	return json_encode($result);
    }
    
    public function verify_otp(Request $request){
		$result = array();
		$email = $request['Email_id'];
		$otp = $request['Otp'];
		
    	$result = ShopperMaster::where(array('Email_id' => $email, 'Otp' => $otp))->get();
    	
		
		
    	if(count($result) >0 ){
			$shoppers = ShopperMaster::find($result[0]['Shopper_id']);
			
			$shoppers->is_validated = 1;
			if($shoppers->save()){
				$result = ShopperMaster::where(array('Email_id' => $email, 'Otp' => $otp))->get();
				$result['message'] = 'Verified';
			}
    		
    	}
    	else{
			$result['message'] = 'Validation error';
		}
    	
    	return json_encode($result);
    }
    
	function generateRandomString($length = 4) {
		$characters = '0123456789';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	public function store(Request $request)
    {
        
		
		
		$mobile =  $request['Mobile_number'];
		$country =  $request['Country_id'];
		$email =  $request['Email_id'];
		$name =  $request['Shopper_name'];
		$gender =  $request['Gender'];
		$shopper = array(
						'Mobile_number' => $mobile,
						'Country_id' => $country,
						'Shopper_name' => $name,
						'Gender' => $gender
						);
		
		$result = ShopperMaster::firstOrFail()
								->where('Email_id', $email)
								->update($shopper);
		
		if($result){
			$inquiry['name'] = $name;
			Mail::to($email)->send(new ShopperSuccess($inquiry));
			$request['success'] = true;
		}
		else{
			$request['success'] = false;
		}
		
		return $request;

    }
	
	
}
