<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\PromotionTag;
use App\PromotionOutlets;
use App\PromotionMaster;
use App\Http\Resources\PromotionTagResource;
use App\Http\Resources\PromotionOutletResource;
use App\Http\Resources\PromoMasterCountResource;
use App\Http\Resources\PromotionMasterResource;


use DB;

class PromotionTagController extends Controller
{
    public function index(){ 
        
    $promo_tags = PromotionTag::join('tags_master','tags_master.tag_id','promotions_tags.tag_id')  
								->join('merchant_master','merchant_master.merchant_id','promotions_tags.merchant_id')
                                ->join('country_master','country_master.country_id','merchant_master.country_id')  
                                 -> leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_tags.merchant_id');
                                                     }) 
                                ->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
                                ->select('promotions_tags.pt_id as pt_id', 'tags_master.tag_name as tag_name', 'tags_master.image as image', 'country_master.country_name', 'merchant_master.merchant_id as merchant_id', 'mall_master.mall_id as mall_id', 'tags_master.tag_id as tag_id')
							    ->groupBy('promotions_tags.tag_id')
                                ->orderBy('promotions_tags.tag_id')
                                ->get();
    	return PromotionTagResource::collection($promo_tags);
    }

     public function tags_plus(){
    
    $promo_tags = PromotionTag::join('tags_master','tags_master.tag_id','promotions_tags.tag_id')  
                                -> leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_tags.merchant_id');
                                                     }) 
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id')     
                                ->join('country_master','mall_master.country_id','country_master.country_id') 	   
                                 ->select('promotions_tags.pt_id as pt_id', 'tags_master.tag_name as tag_name', 'tags_master.image as image', DB::raw("count(promotions_tags.tag_id) as count"),  'country_master.country_name', 'mall_master.mall_id as mall_id', 'tags_master.tag_id as tag_id')
    							->where('mall_master.mt_id', '!=', '1')
    							->groupBy('promotions_tags.tag_id')
    							->orderBy('promotions_tags.tag_id')
    							->get();
    	return PromotionTagResource::collection($promo_tags);
    }

     public function promo_outlets(){
    
    $promo = PromotionOutlets::leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_outlets.merchant_id');
                                                         $join->on('promotions_outlets.mall_id','=','merchant_locations.mall_id');
                                                     }) 
                                ->join('merchant_master','merchant_master.merchant_id','promotions_outlets.merchant_id')
                                ->join('merchant_image','merchant_master.merchant_id','merchant_image.merchant_id')
                                ->join('mall_master','mall_master.mall_id','promotions_outlets.mall_id') 
                                ->join('country_master','mall_master.country_id','country_master.country_id') 
                                ->join('town_master','mall_master.town_id','town_master.town_id') 
                                ->join('merchant_promo_image','merchant_promo_image.promo_id','promotions_outlets.promo_id')
                                ->join('promotions_master','promotions_master.promo_id','promotions_outlets.promo_id') 
                                 ->select('promotions_outlets.*', 'promotions_master.promo_name as promo_name', 'mall_master.mall_name', 'mall_master.lat', 'mall_master.long', 'merchant_promo_image.image_name', 'merchant_locations.merchant_location', 'country_master.country_name', 'merchant_master.merchant_name', 'merchant_image.image_name as merchant_image', 'mall_master.mall_id',
                                        'town_master.town_name',  'promotions_master.other_offer as other_offer', 'promotions_master.start_on as start_on', 'promotions_master.ends_on as ends_on', 'promotions_master.no_end_date as no_end_date', 'promotions_master.active as active' )
                                 ->where('mall_master.mt_id', '=', '1')
                                 ->where('promotions_outlets.live', '=', 'Y')
                                 ->where('merchant_master.merchant_active', '=', 'Y')
                                 ->get();

    	return PromotionOutletResource::collection($promo);
    }

     public function promo_outlets_plus(){
    
    $promo = PromotionOutlets::leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_outlets.merchant_id');
                                                         $join->on('promotions_outlets.mall_id','=','merchant_locations.mall_id');
                                                     }) 
                              	->join('merchant_master','merchant_master.merchant_id','promotions_outlets.merchant_id')
                              	->join('merchant_image','merchant_master.merchant_id','merchant_image.merchant_id')
                                ->join('mall_master','mall_master.mall_id','promotions_outlets.mall_id') 
                                ->join('country_master','mall_master.country_id','country_master.country_id') 
                                ->join('town_master','mall_master.town_id','town_master.town_id') 
								->join('merchant_promo_image','merchant_promo_image.promo_id','promotions_outlets.promo_id')
								->join('promotions_master','promotions_master.promo_id','promotions_outlets.promo_id')  
								 ->select('promotions_outlets.*', 'promotions_master.promo_name as promo_name', 'mall_master.mall_name', 'mall_master.lat', 'mall_master.long', 'merchant_promo_image.image_name', 'merchant_locations.merchant_location', 'country_master.country_name', 'merchant_master.merchant_name', 'merchant_image.image_name as merchant_image', 'mall_master.mall_id',
								        'town_master.town_name',  'promotions_master.other_offer as other_offer', 'promotions_master.start_on as start_on', 'promotions_master.ends_on as ends_on', 'promotions_master.no_end_date as no_end_date', 'promotions_master.active as active'  )
								 ->where('mall_master.mt_id', '!=', '1')
                                 ->where('promotions_outlets.live', '=', 'Y')
                                 ->where('merchant_master.merchant_active', '=', 'Y')
								 ->get();


    	return PromotionOutletResource::collection($promo);
    }
    
    public function promo_master_category(){
    
    $promo = PromotionMaster::join('merchant_promo_image','merchant_promo_image.promo_id','promotions_master.promo_id') 
                                 ->select('promotions_master.*', 'merchant_promo_image.image_name')
                                 ->get();

        return PromoMasterCountResource::collection($promo);
    }

    public function promo_master(){
    
     $promo = PromotionMaster::leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_master.merchant_id');
                                                     }) 
                                ->join('merchant_master','merchant_master.merchant_id','promotions_master.merchant_id')
                                ->join('merchant_image','merchant_master.merchant_id','merchant_image.merchant_id')
                                ->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
                                ->join('country_master','mall_master.country_id','country_master.country_id') 
                                ->join('merchant_promo_image','merchant_promo_image.promo_id','promotions_master.promo_id') 
                                ->join('promotions_tags','promotions_tags.po_id','promotions_master.promo_id') 
                                ->join('tags_master','tags_master.tag_id','promotions_tags.tag_id') 
                                 ->select('promotions_master.*', 'promotions_master.description as promo_description', 'mall_master.mall_name', 'mall_master.lat', 'mall_master.long', 'merchant_promo_image.image_name', 'merchant_locations.merchant_location', 'country_master.country_name', 'merchant_master.merchant_name', 'merchant_image.image_name as merchant_image', 'mall_master.mall_id', 'tags_master.tag_name as tag_name')
                                 ->where('mall_master.mt_id', '=', '1')
                                 ->where('promotions_tags.primary_tag', '=', 'Y')
                                 ->get();

        return PromotionMasterResource::collection($promo);
    }

    public function promo_master_plus(){
    
    $promo = PromotionMaster::leftJoin('merchant_locations', function($join)
                                                     {
                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_master.merchant_id');
                                                     }) 
                                ->join('merchant_master','merchant_master.merchant_id','promotions_master.merchant_id')
                                ->join('merchant_image','merchant_master.merchant_id','merchant_image.merchant_id')
                                ->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
                                ->join('country_master','mall_master.country_id','country_master.country_id') 
                                ->join('merchant_promo_image','merchant_promo_image.promo_id','promotions_master.promo_id') 
                                ->join('promotions_tags','promotions_tags.po_id','promotions_master.promo_id') 
                                ->join('tags_master','tags_master.tag_id','promotions_tags.tag_id') 
                                ->select('promotions_master.*', 'promotions_master.description as promo_description', 'mall_master.mall_name', 'mall_master.lat', 'mall_master.long', 'merchant_promo_image.image_name', 'merchant_locations.merchant_location', 'country_master.country_name', 'merchant_master.merchant_name', 'merchant_image.image_name as merchant_image', 'mall_master.mall_id', 'tags_master.tag_name as tag_name')
                                 ->where('mall_master.mt_id', '!=', '1')
                                 ->where('promotions_tags.primary_tag', '=', 'Y')
                                 ->get();

        return PromotionMasterResource::collection($promo);
    }
 
	
}
