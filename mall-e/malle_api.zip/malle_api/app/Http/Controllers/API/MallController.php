<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\MallMaster;
use App\MallType;
use App\OfferMaster;
use App\Http\Resources\MallResource;
use App\Http\Resources\MallMerchantResource;
use App\Http\Resources\MallTypeResource;
use App\Http\Resources\NoMallResource;
use App\Http\Resources\MerchantInMallResource;
use App\Http\Resources\ParkingResource;
use App\Http\Resources\OfferResource;

use DB;


class MallController extends Controller
{
    public function index(){

    	$malls = MallMaster::where('mall_active', 'Y')->get();

    	return MallResource::collection($malls);
    }
	
	 public function search($id){

    	//$malls = MallMaster::where('mall_id', $id)->get();
		//$user_id = 3;
		
		$malls = MallMaster::where('mall_id', $id)->get();
		
		
    	return MallMerchantResource::collection($malls);
    }
	
	
	 public function view_all(){

    	$malls = MallMaster::where('mall_active', 'Y')->get();

    	return MallResource::collection($malls);
    }
	
	
	
	public function viewmall_all(){

    	//$malls = MallMaster::where('mall_active', 'Y')->groupBy('mall_id')->count();
		
		$malls = MallMaster::join('deal_master','deal_master.mall_id','mall_master.mall_id')
                            //->join('categories','auctions.category_id','categories.id')
                            //->join('sub_catogories','auctions.sub_category_id','sub_catogories.id')
                            ->select(['mall_master.*'])
							->where('mall_master.mall_active', 'Y')
							->where('deal_master.deal_status','L')
                            //->groupBy('deal_master.dm_id','desc')
							->groupBy('deal_master.mall_id')
							->count();
		//$malls->deals = 100;
		
		//var_export($malls);
		//exit();					
    	return MallResource::collection($malls);
    }

   /*  public function view_mall_type(){

    	$mall_type = MallType::get();

    	return MallTypeResource::collection($mall_type);
    }*/

    public function view_choosen_mall_type($id){

    	$mt_choosen = MallMaster::where('mt_id', $id)->get();
		
    	return MallResource::collection($mt_choosen);

    	 
    }
	
	public function view_mall_type_count(){
	 

    	$no_mall =  DB::table('mall_type')
					->join('mall_master', 'mall_type.mt_id', '=', 'mall_master.mt_id')
					->select('mall_type.mt_id as mt_id', 'mall_type.type_name as type_name', 'mall_master.mall_active as mall_active', DB::raw("count(mall_master.mt_id) as count"))
					->where('mall_active', 'Y')
					->groupBy('mall_type.mt_id')
					->orderBy('mall_type.mt_id')
					->get();

				/*	SELECT mall_type.mt_id,
					    count(mall_master.mt_id) AS `count`
					FROM `mall_type` left outer join `mall_master` on mall_type.mt_id = mall_master.mt_id 
					GROUP BY mall_type.mt_id
					ORDER BY mall_type.mt_id ASC

					$no_mall =  DB::table('mall_type')
					->join('mall_master', 'mall_type.mt_id', '=', 'mall_master.mt_id', 'left outer')
					->select('mall_type.mt_id as mt_id', 'mall_type.type_name as type_name', DB::raw("count(mall_master.mt_id) as count"))
					->groupBy('mall_type.mt_id')
					->orderBy('mall_type.mt_id')
					->get();

					*/

    	 return MallTypeResource::collection($no_mall); 
    }
 	

    public function location_merchant_perMall(){ 

    	 	$yes_mall = MallMaster::join('merchant_locations','merchant_locations.mall_id','mall_master.mall_id')->get(); 
			return MerchantInMallResource::collection($yes_mall);
    }
	
   
	public function getParking()
	{
		$parking = MallMaster::join('country_master','country_master.country_id','mall_master.country_id')
							   ->join('town_master','town_master.town_id','mall_master.town_id')
							   ->join('parking_images','parking_images.mall_id','mall_master.mall_id')
							   ->where('parking_images.image_count','=', '1')
							   ->where('mall_master.mt_id', '1')->get(); 
			return ParkingResource::collection($parking);
	}
	public function getParkingPlus()
	{
		$parking = MallMaster::join('country_master','country_master.country_id','mall_master.country_id')
							   ->join('town_master','town_master.town_id','mall_master.town_id')
							   ->join('parking_images','parking_images.mall_id','mall_master.mall_id')
							   ->where('parking_images.image_count','=', '1')
							   ->where('mall_master.mt_id','!=', '1')->get(); 
			return ParkingResource::collection($parking);
	}

	public function getOffers()
	{
		$offers = OfferMaster::join('mall_master','mall_master.mall_id','offer_master.mall_id')
							   ->join('country_master','country_master.country_id','mall_master.country_id')
							   ->join('town_master','town_master.town_id','mall_master.town_id')
							   //->join('mall_offers_images','mall_offers_images.offer_id','offer_master.offer_id')
							    ->where('offer_master.live', 'Y')
							   ->where('mall_master.mt_id', '1')->get(); 
			return OfferResource::collection($offers);

	}

	public function getOffersPlus()
	{
		$offers = OfferMaster::join('mall_master','mall_master.mall_id','offer_master.mall_id')
							   ->join('country_master','country_master.country_id','mall_master.country_id')
							   ->join('town_master','town_master.town_id','mall_master.town_id')
							   //->join('mall_offers_images','mall_offers_images.offer_id','offer_master.offer_id')
							    ->where('offer_master.live', 'Y')
							   ->where('mall_master.mt_id','!=', '1')->get(); 
			return OfferResource::collection($offers);

	}
}
