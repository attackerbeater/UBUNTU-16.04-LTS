<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\EventMaster;
use App\Http\Resources\EventResourceMaster;

class EventController extends Controller
{
    public function index(){

    	$events = EventMaster::join('mall_master','events_master.mall_id','mall_master.mall_id')
                             ->join('mall_type','mall_master.mt_id','mall_type.mt_id')        	 
    						 ->join('user_master','events_master.user_id','user_master.user_id')	
    						 ->join('events_category','events_master.ec_id','events_category.ec_id')
                             ->join('event_image','events_master.event_id','event_image.event_id')
    						 ->join('country_master','country_master.country_id','mall_master.country_id')
    						 ->where('event_image.event_count','1')
    						 ->get();	 

    	return EventResourceMaster::collection($events);
    }
 
	
}
