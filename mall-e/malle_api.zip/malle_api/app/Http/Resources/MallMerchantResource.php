<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MallMerchantResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->mall_id,
            'mall' => $this->mall_name,
            'lat' => $this->lat,
            'long' => $this->long,
            'country' => $this->country,
            'city' => $this->city,
            'town' => $this->town,
            'mall_type' => $this->mall_type,
            //'images' => MallImageResource::collection($this->user),
            //'deals' => $this->deals,
            'subcategories' => SubCategoryResource::collection($this->subcategory)
            //'merchant' => $this->merchants,
        ];
    }
}
