<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DealResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        //return [
        //    'id' => $this->dm_id,
        //    'deal_id' => $this->deal_id,
        //    'date' => $this->deal_date,
        //    'created_by' => AdminResource::collection($this->user),
        //    'merchant' => MerchantResource::collection($this->merchant),
        //    'mall' => MallResource::collection($this->mall),
        //    'status' => $this->deal_status,
        //    'sub_category' => SubCategoryResource::collection($this->subcategory),
        //    'amount' => $this->deal_amount,
        //    'usual_price' => $this->usual_price,
        //    'short_desc' => $this->short_desc,
        //    'images' => DealImageResource::collection($this->images)
        //
        //];
        return [
            'id' => $this->dm_id,
            'deal_id' => $this->deal_id,
            'date' => $this->deal_date,
            'status' => $this->deal_status,
            'amount' => $this->deal_amount,
            'usual_price' => $this->usual_price,
            'deal_main_name' => $this->deal_main_name,
            'short_desc' => $this->short_desc,
            'featured' => $this->featured,
            'mall_type' => $this->type_name,
            'deal_image'=> $this->deal_image,
            'loc'=> $this->loc,
            'active'=> $this->active,
            'created_by' => AdminResource::collection($this->user),
            'merchant' => MerchantResource::collection($this->merchant),
            'mall' => MallResource::collection($this->mall),
            'images' => DealImageResource::collection($this->images),
            

        ];
    }
}
