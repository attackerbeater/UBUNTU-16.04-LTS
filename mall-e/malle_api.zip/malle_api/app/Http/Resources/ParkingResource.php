<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ParkingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
         return [
            'pi_id' => $this->pi_id,
            'mall_id' => $this->mall_id,
            'mall_name' => $this->mall_name,
            'town_name' => $this->town_name,
            'country_name' => $this->country_name,
            'lat' => $this->lat, 
            'lon' => $this->long,   
            'parking_image' => $this->parking_images,   
            'mall_active' => $this->mall_active, 
            'mall_featured' => $this->featured, 
            'mall_logo' => $this->main_image,
            'free_parking' => $this->free_parking,
            'paid_parking' => $this->paid_parking,
            'total_parking' => $this->total_parking,
            'available_parking' => $this->available_parking,
            
        ];  
    }
}
