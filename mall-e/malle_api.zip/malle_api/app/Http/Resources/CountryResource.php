<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CountryResource extends JsonResource{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->country_id,
            'country' => $this->country_name,
            'country_code' => $this->country_code,
            'currency_symbol' => $this->currency_symbol,
            'malls' => $this->mall,
        ];
    }
}
