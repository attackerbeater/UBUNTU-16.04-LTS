<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MerchantResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->merchant_id,
            'merchant' => $this->merchant_name,
            'merchant_locations' => $this->merchant_location,
            'mall' => $this->mall,
            'image' => MerchantImageResource::collection($this->images),
            'm_image' => MerchantImageResource::collection($this->m_images),
            'deals' => $this->deals,
            'mt_id' => $this->mt_id,
            'type' => $this->type,
            'featured' => $this->featured,
            'about_us' => $this->about_us,
            'facebook' => $this->facebook,
            'instagram' => $this->instagram,
            'website' => $this->website,
            'telephone' => $this->loc_telephone,
            'main_image' => $this->main_image,
            'merchant_address' => $this->merchant_address,
            'merchant_active' => $this->merchant_active,
            'opening_hour' => $this->loc_opening_hour,
            'deal_count' => $this->deal_count,
            'outlet_count' => $this->outlet_count,
            'promo_count' => $this->promo_count,
            'promo_count_all' => $this->promo_count_all,
            
            //'promo_count' => $this->promo_count,
            //'outlet_count' => $this->outlet_count,

           // 'categories' => $this->categories
        ];
    }
}
 