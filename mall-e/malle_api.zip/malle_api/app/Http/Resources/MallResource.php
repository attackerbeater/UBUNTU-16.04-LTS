<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MallResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->mall_id,
            'mall' => $this->mall_name,
            'lat' => $this->lat,
            'long' => $this->long,
            'country' => CountryResource::collection($this->country),
            'city' => CityResource::collection($this->city),
            'town' => TownResource::collection($this->town),
            'mall_type' => MallTypeResource::collection($this->mall_type),
            'images' => MallImageResource::collection($this->user),
            'event_images' => EventResource::collection($this->events),
            'merchants' => $this->merchants,
            'deals' => $this->deals,
            'business_address' => $this->business_address,
            'main_image' => $this->main_image,
            'about_us' => $this->about_us,
            'website' => $this->website,
            'facebook' => $this->facebook,
            'instagram' => $this->instagram,
            'twitter' => $this->twitter,
            'youtube' => $this->youtube,
            'opening_hour' => $this->opening_hour,
            'free_parking' => $this->free_parking,
            'paid_parking' => $this->paid_parking,
            'total_parking' => $this->total_parking,
            'available_parking' => $this->available_parking, 
            'managed_by' => $this->managed_by,
            'telephone' => $this->telephone, 
            'featured' => $this->featured,
            'town_name' => $this->town_name,
            'city_name' => $this->city_name,
            'mall_active' => $this->mall_active,
            'event_count'=> $this->event_count,
            'merchant_count'=> $this->merchant_count,
            'deal_count'=> $this->deal_count,
            'promo_count'=> $this->promo_count,
        ];
    }
}

   