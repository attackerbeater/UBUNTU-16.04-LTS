<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PromotionTagResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
         return [
            //'pt_id' => $this->pt_id,
            'tag_id' => $this->tag_id,
            'tag_name' => $this->tag_name,
            'image' => $this->image,
            'count' => $this->count, 
            'country_name' => $this->country_name,  
            'merchant_id' => $this->merchant_id, 
            'mall_id' => $this->mall_id, 
            'promo_outlets' => PromotionOutletResource::collection($this->promo_outlets), 

        ];  
    }
}
