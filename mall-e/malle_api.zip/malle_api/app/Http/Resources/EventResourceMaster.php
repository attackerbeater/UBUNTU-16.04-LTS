<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class EventResourceMaster extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
        return [
            'event_id' => $this->event_id,
            'event_name' => $this->event_name,
            'event_description' => $this->event_description,
            'mall_id' => $this->mall_id,
            'start_date' => $this->start_date,
            'end_date' => $this->end_date,
            'daily' => $this->daily,
            'event_timing' => $this->event_timing,
            'all_day' => $this->all_day,
            'location' => $this->location,
            'event_group_id ' => $this->event_group_id,
            'ec_id' => $this->ec_id,
            'user_id' => $this->user_id,
            'Open_to' => $this->Open_to,
            'created_on' => $this->created_on,
            'lat' => $this->lat,
            'lon' => $this->long,
            'event_image' => $this->event_image,
            'country_id' => $this->country_id,
            'country_name' => $this->country_name,
            'mall_name' => $this->mall_name,
            'mall_type' => $this->type_name,
            'type' => $this->type,
            'just_1_day' => $this->just_1_day,
            'all_day' => $this->all_day,
            'featured' => $this->featured,
            'event_cat' => $this->event_cat,
            'images' => EventImageResource::collection($this->images),
            
        ];
    }
}
