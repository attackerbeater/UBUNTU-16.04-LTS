<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CountForMerchantResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'deal_count' => $this->deal_count,
            'promo_count' => $this->promo_count,
            'outlet_count' => $this->outlet_count
        ];
    }
}
