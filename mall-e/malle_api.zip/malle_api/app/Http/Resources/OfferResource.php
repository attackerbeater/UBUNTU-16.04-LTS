<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class OfferResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $months = ['Jan'=>'01', 'Feb'=>'02', 'Mar'=>'03', 'Apr'=>'04', 'May'=>'05', 'Jun'=>'06', 'Jul'=>'07', 'Aug'=>'08', 'Sep'=>'09', 'Oct'=>'10', 'Nov'=>'11', 'Dec'=>'12'];
        $count = count($months);
        $keys = array_keys($months);
        $start_month = '';
        $end_month = ''; 
        if($this->start_date != '' || $this->End_date != ''){
            $parts = explode('/', $this->start_date);
            $parts2 = explode('/', $this->End_date);
            

             for($i = 0; $i < $count; $i++) {
                if ($this->start_date != '' && $months[$keys[$i]] == $parts[1]) {
                     $start_month = $parts[0] .' '.$keys[$i].' '.$parts[2];
                }
                if ($this->End_date != '' && $months[$keys[$i]] == $parts2[1]) {
                     $start_month = $parts2[0] .' '.$keys[$i].' '.$parts2[2];
                }
            }

            }

         return [
            'mall_name' => $this->mall_name,
            'town_name' => $this->town_name,
            'country_name' => $this->country_name,
            'lat' => $this->lat, 
            'lon' => $this->long,   
            'images' => $this->images,   
            'offer_title' => $this->offer_title, 
            'mall_active' => $this->mall_active, 
            'mall_featured' => $this->featured, 
            'mall_logo' => $this->main_image, 
            'start_date' => $start_month, 
            'no_end_date' => $end_month, 
            'End_date' => $this->End_date, 
            'live' => $this->live, 
            'offer_id' => $this->offer_id, 
            'offer_desc' => $this->offer_desc, 
        ];  
    }
}
