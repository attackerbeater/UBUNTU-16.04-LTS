<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class TransactionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'transcation_id' => $this->transcation_id,
            'dm_id' => $this->dm_id,
            'shopper_id' => $this->shopper_id,
            'deal_by' => $this->deal_by,
            'deal_at' => $this->deal_at,
            'qty' => $this->qty,
            'deal_amount' => $this->deal_amount,
            'total_amount' => $this->total_amount,
            'deal_type' => $this->deal_type,
            'transact_date' => $this->transact_date,
            'transact_time' => $this->transact_time,
            'deal_name' => $this->short_desc,
            'deal_images' => DealImageResource::collection($this->deal_images),
            'merchant_name' => $this->merchant_name,
            'img_merchant' => MerchantImageResource::collection($this->merchant_images),
            'mall_name' => $this->mall_name,
            'city' => $this->city_name,
        ];
    }
}
 