<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PromoMasterCountResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
        return [
            'promo_id' => $this->promo_id,
            'promo_name' => $this->promo_name,
            'image_name' => $this->image_name,   
            'count' => $this->count_outlets,   
        ];  
    }
}
