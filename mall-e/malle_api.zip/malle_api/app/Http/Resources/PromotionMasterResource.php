<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PromotionMasterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
        return [
            'promo_id' => $this->promo_id,
            'promo_name' => $this->promo_name ,
            'promo_description' => $this->promo_description,
            'amount' => $this->amount,
            'mall_id' => $this->mall_id,
            'merchant_id' => $this->merchant_id,
            'dated' => $this->dated, 
            'user_id' => $this->user_id, 
            'mall_name' => $this->mall_name, 
            'merchant_location' => $this->merchant_location,  
            'lat' => $this->lat,  
            'long' => $this->long,   
            'image_name' => $this->image_name,   
            'country_name' => $this->country_name, 
            'merchant_name'=> $this->merchant_name,
            'merchant_image'=> $this->merchant_image,
            'tag_name'=> $this->tag_name,
        ];  
    }
}
