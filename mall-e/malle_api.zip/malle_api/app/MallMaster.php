<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations;
use DB;

class MallMaster extends Model
{
    protected $guarded = [];
	
	protected $primaryKey = 'mall_id';

    protected $table = 'mall_master';

    public function user(){

    	return $this->hasMany(MallImage::class,'mall_id','mall_id');
    }
	
	public function country(){

    	return $this->hasMany(CountryMaster::class,'country_id','country_id');
    }
	
	public function deals(){

    	return $this->hasMany(DealMaster::class,'mall_id','mall_id')->where('deal_status','=', 'L');
    }
	
	public function subcategory(){
		
		$merchants = $this->hasManyThrough('App\SubCategoryMaster', 'App\DealMaster','mall_id','sub_category_id');
		return $merchants;
	}
	
	public function events(){

    	return $this->hasMany(EventMaster::class,'mall_id','mall_id');
    }
	
	public function merchants(){

		$merchants = $this->hasManyThrough('App\MerchantMaster', 'App\MerchantMall','mall_id','merchant_id');
		
		//$merchants_all = $merchants->mapInto(MerchantMaster::class);
		
		//$merchants->all();
		//dd($merchants);
		return $merchants;
	
    	//return $this->hasMany(MerchantMall::class,'mall_id','mall_id');
    }
	
	public function city(){

    	return $this->hasMany(CityMaster::class,'city_id','city_id');
    }
	
	
	public function town(){

    	return $this->hasMany(TownMaster::class,'town_id','town_id');
    }
	
	public function mall_type(){

    	return $this->hasMany(MallType::class,'mt_id','mt_id');
    }

      public function event_count()
	{
			return $this->hasMany(EventMaster::class, 'mall_id', 'mall_id')
	    			->select(DB::raw("count(events_master.event_id) as event_count"))
	    			->where('events_master.type', '=', 'C');
	    			
	}  

	  public function merchant_count()
	{
			return $this->hasMany(MerchantLocations::class, 'mall_id', 'mall_id')
			       ->join('merchant_master','merchant_master.merchant_id','merchant_locations.merchant_id')
	    			->select(DB::raw("count(merchant_locations.merchantLocation_id) as merchant_count"))
	    			->where('merchant_master.merchant_active', '=', 'Y');

	    			
	}  

	  public function deal_count()
	{
			return $this->hasMany(DealMaster::class, 'mall_id', 'mall_id')
	    			->select(DB::raw("count(deal_master.deal_master_id) as deal_count"))
	    			->where('deal_master.deal_status', '=', 'L');

	    			
	} 

	  public function promo_count()
	{
			return $this->hasMany(PromotionOutlets::class, 'mall_id', 'mall_id')
	    			->select(DB::raw("count(promotions_outlets.po_id) as promo_count"))
	    			->where('promotions_outlets.live', '=', 'Y');

	    			
	}  

	public function parking_images(){

    	return $this->hasMany(ParkingImages::class,'mall_id','mall_id');
    }
}
