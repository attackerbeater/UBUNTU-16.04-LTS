<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DealMaster extends Model
{
    protected $guarded = [];
	protected $primaryKey = 'sub_category_id';

    protected $table = 'deal_master';


     	public function user()
	    {
	    	return $this->hasMany(Admin::class, 'user_id', 'created_by');
	    }

	    public function merchant()
	    {
	    	return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id');
	    }

	    public function mall()
	    {	
	    	return $this->hasMany(MallMaster::class, 'mall_id', 'mall_id');	    	
	    }

	    public function subcategory()
	    {
	    	return $this->belongTo(SubCategoryMaster::class, 'sub_category_id', 'sub_category_id');
	    }

   		public function images()
	    {
	    	return $this->hasMany(DealImages::class, 'dm_id', 'dm_id');
	    }

}
