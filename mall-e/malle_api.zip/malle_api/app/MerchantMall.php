<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantMall extends Model
{
    protected $guarded = [];
	
	protected $primaryKey = 'merchant_id';

    protected $table = 'merchant_locations';

    public function mall()
	{
	    	return $this->hasMany(MallMaster::class, 'mall_id', 'mall_id');
	}
	
	 public function merchants()
	{
	    	return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id');
	}
	
	
}
