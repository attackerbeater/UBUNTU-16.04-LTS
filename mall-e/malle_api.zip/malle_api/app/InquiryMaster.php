<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InquiryMaster extends Model
{
	const UPDATED_AT = null;
	const CREATED_AT = null;
	
    protected $fillable = [
						'Inquiry_Date',
						'Outlet_name',
						'Contact_person',
						'Contact_number',
						'Email_id',
						'Country'
						];

    protected $table = 'Inquiry_master';


}
