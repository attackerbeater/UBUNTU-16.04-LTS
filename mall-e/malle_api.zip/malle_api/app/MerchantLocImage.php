<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantLocImage extends Model
{
    protected $guarded = [];
 
    protected $table = 'merchant_loc_image';
}
