<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class TagMaster extends Model
{
    protected $guarded = [];

    protected $table = 'tags_master';
 
}
