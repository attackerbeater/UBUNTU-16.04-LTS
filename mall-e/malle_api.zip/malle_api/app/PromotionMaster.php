<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class PromotionMaster extends Model
{
    protected $guarded = [];

    protected $table = 'promotions_master';


     public function count_outlets()
	{
			return $this->hasMany(PromotionMaster::class, 'promo_id', 'promo_id')
	    			->join('merchant_locations','merchant_locations.merchant_id','promotions_master.merchant_id')
	    			->select(DB::raw("count(merchant_locations.merchant_id) as outlet_count"));

	    			
	}  

}
