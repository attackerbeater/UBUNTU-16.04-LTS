<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class ParkingImages extends Model
{
    protected $guarded = [];

    protected $table = 'parking_images';

}
