<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MerchantType extends Model
{
    
    protected $guarded = [];

    protected $table = 'merchant_type';


		
}
