<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CityMaster extends Model
{
    
    protected $guarded = [];

    protected $table = 'city_master';


	public function user()
	 {
	 	return $this->belongsTo(User::class,'user_id');
	 }
}
