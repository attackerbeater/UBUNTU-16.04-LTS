<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransactionMaster extends Model
{
	const UPDATED_AT = null;
	const CREATED_AT = null;
	protected $primaryKey = 'transcation_id';
	
    protected $guarded = [];
    

    protected $table = 'transactions_master';

  	    public function merchant_images()
	    {
	    	return $this->hasMany(MerchantImage::class, 'merchant_id', 'merchant_id'); 
	    }
	    public function deal_images()
	    {
	    	return $this->hasMany(DealMerchantImages::class, 'dm_id', 'dm_id');
	    }
}


