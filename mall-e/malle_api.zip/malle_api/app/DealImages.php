<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DealImages extends Model
{
    protected $guarded = [];

    protected $table = 'deals_images';
}
