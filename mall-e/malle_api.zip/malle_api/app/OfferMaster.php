<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations;

class OfferMaster extends Model
{
    protected $guarded = [];

    protected $table = 'offer_master';

 	 public function images()
	    {
	    	return $this->hasMany(MallOffersImages::class, 'offer_id', 'offer_id');
	    }
      
}
