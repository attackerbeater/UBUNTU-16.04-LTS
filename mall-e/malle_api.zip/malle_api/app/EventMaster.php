<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EventMaster extends Model
{
    protected $guarded = [];

    protected $table = 'events_master';

    
   		public function images()
	    {
	    	return $this->hasMany(EventImages::class, 'event_id', 'event_id');
	    }
      
}
