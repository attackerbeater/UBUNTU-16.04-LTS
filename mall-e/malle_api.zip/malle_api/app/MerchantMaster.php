<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class MerchantMaster extends Model
{
    protected $guarded = [];

    protected $table = 'merchant_master';

    public function images()
	    {
	    	return $this->hasMany(MerchantImage::class, 'merchant_id', 'merchant_id'); 
	    }
	public function m_images()
	    {
	    	return $this->hasMany(MerchantLocImage::class, 'merchantLocation_id', 'merchantLocation_id')
						->join('merchant_locations','merchant_loc_image.merchantLocation_id','merchant_locations.merchantLocation_id');  
	    }
	public function mall()
	{
	    	return $this->hasMany(MallMaster::class, 'mall_id', 'mall_id')
	    	                    ->join('town_master','town_master.town_id','mall_master.town_id')
								->join('city_master','city_master.city_id','mall_master.city_id')
								->select('town_master.town_name', 'city_master.city_name', 'mall_master.*' );
	    	//return $this->hasMany(DealMaster::class,'sub_category_id','sub_category_id')->where('deal_status','=', 'L');
	    }
	public function merchant_location()
	{
	    	return $this->hasMany(MerchantMall::class, 'merchant_id', 'merchant_id');
	    }
		
	public function deals()
	{
	    	return $this->hasMany(DealMaster::class, 'merchant_id', 'merchant_id');
	}

	public function deal_count()
	{
			return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id')
	    			->join('deal_master','deal_master.merchant_id','merchant_master.merchant_id')
	    			->select( DB::raw("count(deal_master.merchant_id) as deal_count"))
	    			->where('deal_master.deal_status', '=', 'L') ;

	    			
	}

	public function outlet_count()
	{
			return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id')
	    			->join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
	    			->select(DB::raw("count(merchant_locations.merchant_id) as outlet_count"));

	    			
	}

	public function promo_count()
	{
			return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id')
	    			->join('promotions_outlets','promotions_outlets.merchant_id','merchant_master.merchant_id')
	    			->select(DB::raw("count(promotions_outlets.merchant_id) as promo_count"));

	    			
	}

	public function promo_count_all()
	{
			return $this->hasMany(MerchantMaster::class, 'merchant_id', 'merchant_id')
	    			->join('promotions_master','promotions_master.merchant_id','merchant_master.merchant_id')
	    			->select(DB::raw("count(promotions_master.merchant_id) as promo_count_all"))
	    			->where('promotions_master.active', '=', 'Y');

	    			
	}

	public function merchants(){

    	return $this->hasMany(MerchantMaster::class,'mt_id','mt_id')
    				->join('merchant_locations','merchant_locations.merchant_id','merchant_master.merchant_id')
								->join('mall_master','mall_master.mall_id','merchant_locations.mall_id') 
								->join('merchant_type', 'merchant_type.mt_id', 'merchant_master.mt_id')
								->select('merchant_master.main_image', 'merchant_locations.*','merchant_type.*','merchant_master.*')
								->where('merchant_master.merchant_active', 'Y')
								->where('mall_master.mt_id', '=', '1'); 
    }


	
	
}
