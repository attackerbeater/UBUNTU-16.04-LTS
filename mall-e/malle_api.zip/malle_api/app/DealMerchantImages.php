<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DealMerchantImages extends Model
{
    protected $guarded = [];

    protected $table = 'deal_merchant_images';
}
