<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CountryMaster extends Model
{
    
    protected $guarded = [];

    protected $table = 'country_master';


	public function user()
	 {
	 	return $this->belongsTo(User::class,'user_id');
	 }
	public function mall()
    {	
    	return $this->hasMany(MallMaster::class, 'country_id', 'country_id')->where('mall_master.mall_active', 'Y');	    	
    }
}
