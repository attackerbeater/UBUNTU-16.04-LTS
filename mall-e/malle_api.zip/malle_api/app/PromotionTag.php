<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use DB;

class PromotionTag extends Model
{
    protected $guarded = [];

    protected $table = 'promotions_tags';


     public function count()
	{
			return $this->hasMany(TagMaster::class, 'tag_id', 'tag_id') 
			       		->join('promotions_tags','tags_master.tag_id','promotions_tags.tag_id')
	    				->select(DB::raw("count(promotions_tags.tag_id) as count"));

	    			
	}  

	  public function promo_outlets()
	{
		    return $this->hasMany(TagMaster::class, 'tag_id', 'tag_id') 
			       		->join('promotions_tags','tags_master.tag_id','promotions_tags.tag_id')
		    			->join('promotions_outlets','promotions_outlets.po_id','promotions_tags.po_id')
		    			->leftJoin('merchant_locations', function($join)
	                                                     {
	                                                         $join->on('merchant_locations.merchant_id', '=', 'promotions_outlets.merchant_id');
	                                                         $join->on('promotions_outlets.mall_id','=','merchant_locations.mall_id');
	                                                     }) 
                        ->join('merchant_master','merchant_master.merchant_id','promotions_outlets.merchant_id')
                        ->join('merchant_image','merchant_master.merchant_id','merchant_image.merchant_id')
                        ->join('mall_master','mall_master.mall_id','promotions_outlets.mall_id') 
                        ->join('country_master','mall_master.country_id','country_master.country_id') 
                        ->join('town_master','mall_master.town_id','town_master.town_id') 
                        ->join('merchant_promo_image','merchant_promo_image.promo_id','promotions_outlets.promo_id')
                        ->join('promotions_master','promotions_master.promo_id','promotions_outlets.promo_id') 
                         ->select('promotions_outlets.*', 'promotions_master.promo_name as promo_name', 'mall_master.mall_name', 'mall_master.lat', 'mall_master.long', 'merchant_promo_image.image_name', 'merchant_locations.merchant_location', 'country_master.country_name', 'merchant_master.merchant_name', 'merchant_image.image_name as merchant_image', 'mall_master.mall_id',
                                        'town_master.town_name',  'promotions_master.other_offer as other_offer', 'promotions_master.start_on as start_on', 'promotions_master.ends_on as ends_on', 'promotions_master.no_end_date as no_end_date' )
                         ->where('promotions_outlets.live', '=', 'Y')
                         ->where('merchant_master.merchant_active', '=', 'Y');

	    			
	}  
 
}
