<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class SubCategoryMaster extends Model
{
    protected $guarded = [];

    protected $table = 'sub_category_master';
    
    public function deals(){

    	return $this->hasMany(DealMaster::class,'sub_category_id','sub_category_id')
    						->join('deals_images','deals_images.di_id','deal_master.di_id') 
                            ->join('deals_main','deals_main.dm_id','deal_master.dm_id') 
    						->join('mall_master', 'deal_master.mall_id', 'mall_master.mall_id')
    	                    ->join('mall_type', 'mall_type.mt_id', 'mall_master.mt_id')
    	                    ->select('mall_type.type_name', 'deal_master.*', 'deals_images.deal_image as deal_image', 'deals_main.deal_main_name as deal_main_name', 'deals_images.loc as loc', 'deals_main.active as active')
    	                     ->where('deal_master.deal_status','=', 'L')
    	                    ->where('mall_type.mt_id','=', '1');
    }
    
}
