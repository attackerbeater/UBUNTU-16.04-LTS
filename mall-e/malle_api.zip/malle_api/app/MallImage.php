<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MallImage extends Model
{
    protected $guarded = [];

    protected $table = 'mall_image';
}
